# ترجمة — Tarjama

استوديو ترجمة الفيديو إلى العربية مع حرق التسميات على الفيديو.
AI-powered Arabic video caption studio with burned-in subtitles.

## كيف يعمل / How it works

- الواجهة (`index.html`) تستخرج الصوت من الفيديو في المتصفح
- ترسله إلى خادم Netlify الوسيط (`netlify/functions/`)
- الخادم يستدعي OpenAI Whisper (تفريغ) و GPT-4o-mini (ترجمة) بمفتاح مخفي
- التسميات تُحرق على الفيديو وتُنزّل

## النشر / Deployment

1. ارفع هذا المجلد إلى GitHub
2. اربط المستودع بـ Netlify (Add new site → Import from GitHub)
3. بعد إنشاء الموقع، أضف متغير البيئة:
   - **Site settings → Environment variables → Add a variable**
   - Key: `OPENAI_API_KEY`
   - Value: `sk-...` (مفتاحك)
4. أعد النشر (Deploys → Trigger deploy)

## مهم / Important

- لا تضع المفتاح في أي ملف داخل المشروع — فقط في Environment Variables
- الحد المجاني: 5 دقائق لكل فيديو، حجم حتى 1 جيجابايت
