// netlify/functions/transcribe.js
// Receives audio, sends to OpenAI Whisper using the SECRET key.
// The key lives in Netlify env vars — never exposed to the browser.

exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: 'Method not allowed' };
  }

  const KEY = process.env.OPENAI_API_KEY;
  if (!KEY) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server missing OPENAI_API_KEY' }) };
  }

  try {
    // Body arrives base64-encoded from the browser
    const { audioBase64, mimeType, language } = JSON.parse(event.body);
    if (!audioBase64) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'No audio provided' }) };
    }

    const audioBuffer = Buffer.from(audioBase64, 'base64');

    // Build multipart form for OpenAI
    const form = new FormData();
    const ext = (mimeType || '').includes('wav') ? 'wav'
      : (mimeType || '').includes('ogg') ? 'ogg' : 'webm';
    const blob = new Blob([audioBuffer], { type: mimeType || 'audio/webm' });
    form.append('file', blob, 'audio.' + ext);
    form.append('model', 'whisper-1');
    form.append('response_format', 'verbose_json');
    form.append('timestamp_granularities[]', 'segment');
    form.append('timestamp_granularities[]', 'word');
    if (language && language !== 'auto') form.append('language', language);

    const r = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + KEY },
      body: form,
    });

    const text = await r.text();
    if (!r.ok) {
      return { statusCode: r.status, headers: cors, body: text };
    }
    return { statusCode: 200, headers: { ...cors, 'Content-Type': 'application/json' }, body: text };

  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: e.message }) };
  }
};
