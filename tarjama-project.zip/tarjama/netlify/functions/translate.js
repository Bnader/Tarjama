// netlify/functions/translate.js
// Translates subtitle segments to Arabic using OpenAI GPT-4o-mini.
// Uses the SAME secret OPENAI_API_KEY — no Anthropic key needed.

exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: 'Method not allowed' };
  }

  const KEY = process.env.OPENAI_API_KEY;
  if (!KEY) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server missing OPENAI_API_KEY' }) };
  }

  try {
    const { text } = JSON.parse(event.body); // numbered lines: "[0] Hello\n[1] World"
    if (!text) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'No text provided' }) };
    }

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.3,
        messages: [
          {
            role: 'system',
            content:
              'You are a professional Arabic subtitle translator. Translate each numbered segment into natural Modern Standard Arabic (الفصحى المعاصرة). Keep the [N] index prefix on every line. Keep translations concise — these are subtitles. Preserve tone. Output ONLY the translated lines, nothing else.',
          },
          { role: 'user', content: text },
        ],
      }),
    });

    const data = await r.json();
    if (!r.ok) {
      return { statusCode: r.status, headers: cors, body: JSON.stringify(data) };
    }

    const out = data.choices?.[0]?.message?.content || '';
    return {
      statusCode: 200,
      headers: { ...cors, 'Content-Type': 'application/json' },
      body: JSON.stringify({ translation: out }),
    };

  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: e.message }) };
  }
};
